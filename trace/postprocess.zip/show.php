<?php

require 'jsffun.php';
require 'font8.php';

/*********************************************************************/

$framecounter = 0;


define('FNW', 6);
define('FNH', 9);
define('FNVH', 8);
//define('FNMASK', 0x8000);
define('FNMASK', 0x80);

class JSF_PNGout
{
  private $x, $y, $im;
  private $xo, $yo;
  private $active_ins;
  private $half;
  private $font;
  
  function __construct()
  {
    $this->x = 0;
    $this->y = 0;
    $this->im = ImageCreateTrueColor(100*FNW + 110*FNW + 172*FNW, 954*FNVH/3);
    $this->active_ins = false;
    $this->xo = 0;
    $this->yo = 0;
    
    $this->half = Array();
    for($g=0; $g<256; ++$g)
      $this->half[$g] = (int)(255*pow(pow($g/255.0, 1/2.2) * 0.9, 2.2));
  
    $this->font = Array();

    $cur = 0;
    $in_bitmap = false;
    foreach(file('font.bdf') as $line)
    {
      if(preg_match('/^ENCODING (.*)/', $line, $mat))
        $cur = ((int)$mat[1]) * FNH;
      elseif($line == "BITMAP\n")
        $in_bitmap = true;
      elseif($line == "ENDCHAR\n")
        $in_bitmap = false;
      elseif($in_bitmap)
        $this->font[$cur++] = hexdec($line);
    }
  }
  function __destruct()
  {
    global $framecounter;

    ImageGif($this->im, $name=sprintf('gif/imageframe%06d.gif', $framecounter));
    print "Wrote $name\n";

    ImageDestroy($this->im);
  }
  public function AppendText($text, $pending_span, &$pending_color)
  {
    global $font8, $active_colors;
    global $visit;

    $b = strlen($text);
    for($a=0; $a<$b; ++$a)
    {
      $c = $text[$a];
      if($c == "\r") continue;
      if($c == "\n")
      {
        $this->x=0; $this->y+=1;
        $this->active_ins = false;
        if($this->y == 318)
        {
          $this->xo += 100;
          $this->yo = -$this->y;
        }
        elseif($this->y == 635)
        {
          $this->xo += 110;
          $this->yo = -$this->y;
        }
        continue;
      }
      $char = ord($c);

      $color = JSF_Parser::GenTrueColorsFor($pending_color);

      $bgcolor = $color[0];
      $fgcolor = $color[1];
      
      $comment = ($fgcolor == 0xD75F5F); // fg_411
      
      $v = @$visit[$this->y];
      if(isset($v))
      {
        $v = @$v[$this->x];
        if(isset($v))
          $this->active_ins = $v;
      }

      if(!$comment)
      {
        $cr = $fgcolor >> 16;
        $cg = ($fgcolor >> 8) & 0xFF;
        $cb = $fgcolor & 0xFF;
        if($this->active_ins)
        {
          $bgcolor = $active_colors[$this->active_ins]; // ACTIVE INSTRUCTION
          $fgcolor = 0xFFFFFF;
        }
        else
        {
          $gray = (int)(($cr*299 + $cg*587 + $cb*114) / 1000);
          $cr = $gray;
          $cg = $gray;
          $cb = $gray;
          //$cr = ($gray*7 + $cr * 7) >> 4;
          //$cg = ($gray*7 + $cg * 9) >> 4;
          //$cb = ($gray*7 + $cb * 6) >> 4;
          $fgcolor = ($cr << 16) + ($cg << 8) + $cb;
        }
      }
      
      if($bgcolor != 0 || $char != 32)
      {
        $bx = ($this->x + $this->xo) * FNW;
        $by = ($this->y + $this->yo) * FNVH;
        $idx = $char * FNH;
        for($py=0; $py<FNH; ++$py)
        {
          $line = @$this->font[$idx+$py];
          for($px=0; $px<FNW; ++$px)
          {
            $p = $line & (FNMASK >> $px);
            if($p)
              ImageSetPixel($this->im, $bx+$px, $by, $fgcolor);
            elseif($bgcolor)
              ImageSetPixel($this->im, $bx+$px, $by, $bgcolor);
          }
          ++$by;
        }
      }
      $this->x += 1;
    }
  }
};

/*********************************************************************/

$modulo = (int)$argv[1];
$match  = (int)$argv[2];


$map = Array();
preg_match_all('/^([0-9a-f]*) t BisqLine_([0-9]+)_([0-9]+)_([0-9]+)_([0-9]+)$/m',
               file_get_contents('line-listings.txt'), $res);
foreach($res[1] as $n => $addr)
  $map[ hexdec($addr) ] = Array('file' => (int) $res[2][$n],
                                'row'  => (int) $res[4][$n] - 1,
                                'col'  => (int) $res[5][$n] - 1);

$model = Array();
foreach($map as $addr => $rec)
  $model[ $rec['row'] ] [ $rec['col'] ] = 0;

$source = file_get_contents('nesemu1.cc');

$fp = fopen('nestrace2.log', 'rb');
$size = (int)fgets($fp, 32);

$jsf = new JSF_Parser('c');
$jsf->ParseSyntax(file('c.jsf'));

$active_colors = Array();

$gamma = 1.5;
for($n=0; $n<=4; ++$n)
{
  $r = (int)(255 * pow($n/30, 1/$gamma));
  $g = (int)(255 * pow($n/10, 1/$gamma));
  $b = (int)(255 * pow($n/4, 1/$gamma));
  $active_colors[] = $r*0x10000 + $g*0x100 + $b;
}
$visit = $model;
for(;;)
{
  $data = fread($fp, $size);
  if(feof($fp)) break;

  foreach($visit as &$rec)
    foreach($rec as &$col)
      if($col > 0)
        --$col;
  unset($col);
  unset($rec);

  foreach($map as $addr => $rec)
  {
    $p = $addr - 0x400000;
    $m = ord($data[$p >> 3]);
    $a = 1 << ($p&7);
    if( $m & $a )
      $visit[ $rec['row'] ] [ $rec['col'] ] = 4;
  }

  if( ($framecounter % $modulo == $match)
#  && ($framecounter == 0 || $framecounter >= 7700)
    )
  {
    $r = new JSF_Renderer($jsf, new JSF_PNGout);
    $a = new JSF_Applier($jsf, $r);
    $a->ApplyJSF($source);
    unset($a);
    unset($r);
  }
  else
    print "skipped $framecounter, not %$modulo==$match\n";
  
  ++$framecounter;
}
